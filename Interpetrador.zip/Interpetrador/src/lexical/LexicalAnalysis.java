package lexical;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PushbackInputStream;

public class LexicalAnalysis implements AutoCloseable {
    
    private SymbolTable st = new SymbolTable();
    private int line;
    private PushbackInputStream input;

    public LexicalAnalysis(String filename) throws LexicalException {
        try {
            input = new PushbackInputStream(new FileInputStream(filename));
        } catch (Exception e) {
            throw new LexicalException("Unable to open file");
        }

        line = 1;
    }

    public void close() throws Exception {
        input.close();
    }

    public int line() {
        return this.line;
    }

    public Lexeme nextToken() throws IOException{
        Lexeme lex = new Lexeme("", TokenType.END_OF_FILE);
         
        int estado = 1;
         
        int caractere;
         
        while (estado != 9 && estado != 10) {
             
            caractere = input.read();
             
            switch (estado) {
                case 1:
                    if (caractere == -1) estado = 10;
                    else if (caractere == ' ' || caractere == '\t' ||
                            caractere == '\r' || caractere == '\n') estado = 1;
                    else if (caractere == '#') estado = 2;
                    else if (Character.isDigit(caractere)) {
                        lex.token += (char) caractere;
                        estado = 3;
                    }
                    else if (caractere == '!') estado = 4;
                    else if (caractere == '=' || caractere == '<' || caractere == '>') estado = 5;
                    else if (caractere == '-') estado = 6;
                    else if (Character.isLetter(caractere)) {
                        lex.token += (char) caractere;
                        estado = 7;
                    }
                    else if (caractere == '\"') estado = 8;
                    else if (caractere == ';' || caractere == ':' || caractere == '.' ||
                                caractere == ',' || caractere == '(' || caractere == ')' ||
                                caractere == '{' || caractere == '}' || caractere == '[' ||
                                caractere == ']' || caractere == '+' || caractere == '*' ||
                                caractere == '/' || caractere == '%') estado = 9;
                    else {
                        lex.token += (char) caractere;
                        lex.type = TokenType.INVALID_TOKEN;
                    }
                    estado = 10;
                    break;
                    
                case 2:
                    if (caractere != '\n') estado = 2;
                    else estado = 1;
                    break;
                     
                case 3:
                    if (Character.isDigit(caractere)) lex.token += (char) caractere;
                    else {
                        if (caractere != -1) input.unread(caractere);
                        estado = 10;
                        lex.type = TokenType.NUMBER;
                    }
                    break;
                     
                case 4:
                    if (caractere == '=') {
                        lex.token += (char) caractere;
                        estado = 9;
                    }
                    else {
                        if (caractere == -1) {
                            lex.type = TokenType.UNEXPECTED_EOF;
                        }
                        else {
                            lex.type = TokenType.INVALID_TOKEN;
                        }
                        estado = 10;
                    }
                    break;
                     
                case 5:
                    if (caractere == '=') estado = 9;
                    else {
                        input.unread(caractere);
                        estado = 9;
                    }
                    break;
                     
                case 6:
                    if (caractere == '>') estado = 9;
                    else {
                        input.unread(caractere);
                        estado = 9;
                    }
                    break;
                     
                case 7:
                    if (Character.isLetter(caractere) || Character.isDigit(caractere)) {
                        lex.token += (char) caractere;
                        estado = 7;
                    }
                    else {
                        input.unread(caractere);
                        estado = 9;
                    }
                    break;
                     
                case 8:
                    if (caractere == '\"') {
                        lex.type = TokenType.STRING;
                        estado = 10;
                    }
                    else {
                        if (caractere == -1) {
                            lex.type = TokenType.UNEXPECTED_EOF;
                            estado = 10;
                        }
                        else {
                            lex.token += (char) caractere;
                        }
                    }
                    break;
            }
        }
        
        if (estado == 9) {
            if (st.contains(lex.token)) lex.type = st.find(lex.token);
            else lex.type = TokenType.VAR;
        }
        return lex;
    }
}
