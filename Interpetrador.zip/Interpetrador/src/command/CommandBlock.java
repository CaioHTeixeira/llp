/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @author 
 */
public class CommandBlock extends Command {
    private List<Command> commands;

    public CommandBlock() {
        super(-1);
        commands = new ArrayList<Command>();
    }
    public void addCommand(Command c){
            this.commands.add(c);
    }
    public void  execute(){   
       for( Command c: commands){
           c.execute();
       }
    }
            
    
    
}
