/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import java.util.ArrayList;
import java.util.List;
import value.ConstIntValue;
import value.IntValue;
import value.ArrayValue;
import value.ConstStringValue;
import value.ConstArrayValue;
import value.RefArrayValue;
import value.StringValue;
import value.Value;
import value.Variable;

/**
 *
 * @author usuario
 */
public class AssignCommand extends Command{
    private List<Variable> vars;
    private Value<?> value;
    public AssignCommand(Variable var, Value<?> value, int line){
        super(line);
        this.vars = new ArrayList<Variable>();
        this.value = value;
    }
    
    public void addVariable(Variable v) {
        this.vars.add(v);
    }

    public void execute() {
    // Se o valor for uma variável, sempre obtenha o valor que ela guarda.
    // Caso contrário, usa o próprio valor.
    Value<?> value = (this.value instanceof Variable) ? ((Variable) this.value).value() : this.value;
    
    Value<?> newValue = null;
    if (value instanceof IntValue) {
      IntValue iv = (IntValue) value;
      newValue = new ConstIntValue(iv.value(), -1);
    } else if (value instanceof StringValue) {
      StringValue sv = (StringValue) value;
      newValue = new ConstStringValue(sv.value(), -1);
    } else if (value instanceof ArrayValue) {
      ArrayValue av = (ArrayValue) value;
      newValue = new ConstArrayValue(av);
    } else {
      // Impossível pela gramática.
    }
 
    for (Variable v : this.vars) {
      v.setValue(newValue);
    }
    // Se o valor for inteiro, obter o número e guardar em um ConstIntValue
    // para que possa ser armazenado na variável
    if (v instanceof IntValue) {
      ConstIntValue cv = new ConstIntValue(((IntValue) v).value(), super.line());
      var.setValue(cv);
    // Se o valor for uma matriz, obter a matrix e guardar num RefMatrixValue
    // para que possa ser armazenado na variável. Repare que a matriz é a mesma,
    // o efeito é como se fosse uma passagem via referência.
    } else if (v instanceof ArrayValue) {
      RefArrayValue rv = new RefArrayValue(((ArrayValue) v).value(), super.line());
      var.setValue(rv);
    } else {
      System.out.println("Tipo invalido");
      System.exit(1);
    }
        
  }
}
