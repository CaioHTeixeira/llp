package command;

import value.BoolValue;

public class WhileCommand extends Command{
	private BoolValue expr;
	private Command cmd;
	
	
	public WhileCommand(BoolValue expr,Command cmd,int line){
		super(line);
		this.cmd=cmd;
		this.expr=expr;
	}
	public void execute(){
                while(expr.value() == true){
                    cmd.execute();
                }
	}
}
