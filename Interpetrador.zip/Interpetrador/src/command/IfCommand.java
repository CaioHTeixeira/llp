/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package command;

import value.BoolValue;

/**
 *
 * @author usuario
 */
public class IfCommand extends Command {

    private BoolValue expr;
    private Command then;
    private Command Else;

    public IfCommand(BoolValue expr, Command then, int line) {
        super(line);
        this.expr = expr;
        this.then = then;
    }

    public IfCommand(BoolValue expr, Command then, Command Else, int line) {
        super(line);
        this.expr = expr;
        this.then = then;
        this.Else = Else;
    }

    public void execute() {
 
        if (Else != null) {
            if (expr.value() == true) {
                then.execute();
            } else {
                Else.execute();
            }
        } else {
             if (expr.value() == true) {
                then.execute();
            }
        }
    }
}
