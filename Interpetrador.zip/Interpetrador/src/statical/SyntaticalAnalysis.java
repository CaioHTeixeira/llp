package statical;

import command.Command;
import command.CommandBlock;
import command.PrintCommand;
import value.Value;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import lexical.*;
import value.Variable;

public class SyntaticalAnalysis {
    private Lexeme current;
    private LexicalAnalysis lex;
    private Map<String, Variable> vars = new HashMap<String, Variable>();
    
    
    public SyntaticalAnalysis (LexicalAnalysis lex) {
        this.lex = lex;
        try {
            this.current = lex.nextToken();
        } catch (IOException ex) {
            Logger.getLogger(SyntaticalAnalysis.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void matchToken (TokenType type) {
        if (current.type == type) {
            try {
                current = lex.nextToken();
            } catch (IOException ex) {
                Logger.getLogger(SyntaticalAnalysis.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else {
            showError();
        }
    }
    
    public Command init() throws IOException {
        Command c = procStatements();
        matchToken(TokenType.END_OF_FILE);
        return c;
    }
    
    //<statements> ::= <cmd> { <cmd> }
    private Command procStatements() {
        CommandBlock cb = new CommandBlock();
        Command c = procCmd();
        cb.addCommand(c);
        while (current.type == TokenType.PLUS ||
               current.type == TokenType.MINUS ||
               current.type == TokenType.NUMBER ||
               current.type == TokenType.LOAD ||
               current.type == TokenType.NEW ||
               current.type == TokenType.VAR ||
               current.type == TokenType.PAR_OPEN ||
               current.type == TokenType.PRINT ||
               current.type == TokenType.PRINTLN ||
               current.type == TokenType.IF ||
               current.type == TokenType.WHILE) {
            cb.addCommand(procCmd());
        }
        return cb;
    }
    //<cmd>        ::= <assign> | <print> | <if> | <while>
    private Command procCmd () {
        Command s;
        if (current.type == TokenType.PLUS || 
            current.type == TokenType.MINUS ||
            current.type == TokenType.NUMBER ||
            current.type == TokenType.LOAD ||
            current.type == TokenType.NEW ||
            current.type == TokenType.VAR ||
            current.type == TokenType.PAR_OPEN) {
            c = procAssign();
        }
        else if (current.type == TokenType.PRINT ||
                 current.type == TokenType.PRINTLN) {
            c = procPrint();
        }
        else if (current.type == TokenType.IF) {
            c = procIf();
        }
        else if (current.type == TokenType.WHILE) {
            c = procWhile();
        }
        else showError();
    }
    
    
    
    //<assign>     ::= <expr> [ ':' <var> {‘,’<var> } ] ';'
    private void procAssign () {
        procExpr();
        if (current.type == TokenType.VAR) {
            procVar();
            while (current.type == TokenType.COMMA) {
                matchToken(TokenType.COMMA);
                procVar();
            }
        }
        matchToken(TokenType.DOT_COMMA);
    }
    //<print>      ::= (print | println) '(' <text> ')' ';'
    private PrintCommand procPrint () {
        int line = lex.line();;
        boolean newLine = false; // inicializando com false
        if (current.type == TokenType.PRINT) {
            matchToken(TokenType.PRINT);
            newLine = false;
        }
        else if (current.type == TokenType.PRINTLN) {
            matchToken(TokenType.PRINTLN);
            newLine = true;
        }
        else showError();
        matchToken(TokenType.PAR_OPEN);
        Value<?> v = procText();
        matchToken(TokenType.PAR_CLOSE);
        matchToken(TokenType.DOT_COMMA);
        PrintCommand pc = new PrintCommand(v, newLine, line);
        return pc;
    }
    //<if>         ::= if <boolexpr> '{' <statements> '}' [else '{' <statements> '}']
    private void procIf () {
        matchToken(TokenType.IF);
        procBoolExpr();
        matchToken(TokenType.CBRA_OPEN);
        procStatements();
        matchToken(TokenType.CBRA_CLOSE);
        if (current.type == TokenType.ELSE) {
            matchToken(TokenType.ELSE);
            matchToken(TokenType.CBRA_OPEN);
            procStatements();
            matchToken(TokenType.CBRA_CLOSE);
        }
    }
    //<while>      ::= while <boolexpr> '{' <statements> '}'
    private void procWhile () {
        matchToken(TokenType.WHILE);
        procBoolExpr();
        matchToken(TokenType.CBRA_OPEN);
        procStatements();
        matchToken(TokenType.CBRA_CLOSE);
    }
    
    
    
    //<text>       ::= (<string> | <expr>) {‘,’(<string> | <expr>) }
    private Value<?> procText () {
        Value<?> v;
        if (current.type == TokenType.STRING) v = procString();
        else if (current.type == TokenType.PLUS ||
                 current.type == TokenType.MINUS) procExpr();
        while(...) {...}
        returnv;
    }

    
    
    //<boolexpr>   ::= <expr> <boolop> <expr> { (and | or) <boolexpr> }
    private void procBoolExpr () {
        
    }
    //<boolop>     ::= '==' | '!=' | '<' | '>' | '<=' | '>='
    private void procBoolOp () {
        
    }

    
    
    //<expr>       ::= <term> [ ('+' | '-') <term> ]
    private void procExpr () {
        
    }
    //<term>       ::= <factor> [ ('*' | '/' | '%') <factor> ]
    private void procTerm () {
        
    }
    //<factor>     ::= [‘+’| ‘-‘] <number> | <load> | <value> | '(' <expr> ')'
    private void procFactor () {
        
    }
    //<load>       ::= load '(' <text> ')'
    private void procLoad () {
        matchToken(TokenType.LOAD);
        matchToken(TokenType.PAR_OPEN);
        procText();
        matchToken(TokenType.PAR_CLOSE);
    }
    //<value>      ::= (<new> | <var>) { '.' <array> } [ . <int> ]
    private void procValue () {
        if (current.type == TokenType.NEW) procNew();
        else procVar();
        while (current.type == TokenType.DOT) {            
            matchToken(TokenType.DOT);
            if (current.type == TokenType.AT || current.type == TokenType.SIZE) {
                procInt();
                break;
            }
            else procArray();
        }
    }

    
    
    
    //<new>        ::= new (<nzero> | <nrand> | <nfill>)
    private void procNew () {
        matchToken(TokenType.NEW);
        if (current.type == TokenType.ZERO) procNZero();
        else if (current.type == TokenType.RAND) procNRand();
        else if (current.type == TokenType.FILL) procNFill();
        else showError();
    }
    //<nzero>      ::= zero '[' <expr> ']' 
    private void procNZero () {
        
    }
    //<nrand>      ::= rand '[' <expr> ']' 
    private void procNRand () {
        
    }
    //<nfill>      ::= fill '[' <expr> ',' <expr> ']' 
    private void procNFill () {
        
    }

    
    
    
    //<array>      ::= <show> | <sort> | <add> | <set> | <filter> | <remove> | <each> | <apply>
    private void procArray () {
        
    }
    //<show>       ::= show '(' ')'
    private void procShow () {
        
    }
    //<sort>       ::= sort '(' ')'
    private void procSort () {
        
    }
    //<add>        ::= add '(' <expr> ')'
    private void procAdd () {
        
    }
    //<set>        ::= set '(' <expr> ',' <expr> ')'
    private void procSet () {
        
    }
    //<filter>     ::= filter '(' <var> '->' <boolexpr> ')'
    private void procFilter () {
        
    }
    //<remove>     ::= remove '(' <var> '->' <boolexpr> ')'
    private void procRemove () {
        
    }
    //<each>       ::= each '(' <var> '->' <statements> ')'
    private void procEach () {
        
    }
    //<apply>      ::= apply '(' <var> '->' <statements> ')'
    private void procApply () {
        
    }

    
    
    
    //<int>        ::= <at> | <size>
    private void procInt () {
        
    }
    //<at>         ::= at '(' <expr> ')'
    private void procAt () {
        
    }
    //<size>       ::= size '(' ')'
    private void procSize () {
        
    }
    
    
    
    
    //<number>
    private void procNumber () {
        matchToken(TokenType.NUMBER);
    }
    //<string>
    private ConstStringValue procString () {
        int line = lex.line();
        String s = current.token;
        matchToken(TokenType.STRING);
        ConstStringvalue csv = new ConstStringValue(s, line);
        return csv;
    }
    //<var>
    private Variable procVar () {
        String name = current.token;
        matchToken(TokenType.VAR);
        Variable var;
        if(vars.containsKey(name)) {
            var = vars.get(name);            
        } else {
            var = new Variable(name);
            vars.put(name, var);
        }
        return var;
    }
    
    
    
    private void showError () {
        //Lexema não esperado
        //Fim de arquivo não esperado
        System.exit(1);
    }
}
