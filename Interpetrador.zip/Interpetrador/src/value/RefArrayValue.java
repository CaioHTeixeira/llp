/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package value;

/**
 *
 * @author matheus
 */
public class RefArrayValue extends ArrayValue{
    private Array m;

    public RefArrayValue(Array m,int line) {
        super(line);
        this.m = m;
    }
    
    public Array value(){
        return m;
    }
    
}
