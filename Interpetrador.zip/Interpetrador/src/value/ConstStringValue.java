/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package value;


import lexical.TokenType;


/**
 *
 * @author 
 */
public class ConstStringValue extends StringValue {
    private String text;

    public ConstStringValue(String text, int line) {
        super(line);
        this.text = text;
    }
    
    public String value() {
        return text;
    }/*
    private ConstStringValue recStr() {
     String text = current.token;   
     int line = lex.getLine();
     matchToken(TokenType.STRING);
     ConstStringValue csv = new ConstStringValue(text, line);
     return csv;
    }*/
}
