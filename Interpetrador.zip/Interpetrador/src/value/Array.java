/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package value;

import java.util.Random;

/**
 *
 * @author 
 */
public class Array {

    private int pos; //length
    private int Array[];

    public Array(int pos) {
        this.pos = pos;
    }
    public void setPos(int pos) {
        this.pos = pos;
    }

    public void setValue(int pos, int v) {
        this.Array[pos] = v;
    }/*
    public void each(int pos, int v) {
        this.Array[pos] = v;
    }
    public void apply(int pos, int v) {
        this.Array[pos] = v;
    }*/
    /*
    ---- obter um novo vetor abaixo
    public void sort(int pos, int v) {
        this.Array[pos] = v;
    }
    public void add(int pos, int v) { ->se v for inteiro: obtém	 um novo vetor adicionando 
    o novo valor v ao final do vetor x.
    Se v for vetor: obtém um novo vetor	da concatenação do vetor x com o vetor v. <-
        this.Array[pos] = v;
    }
    public void filter(int pos, int v) {
        this.Array[pos] = v;
    }
    public void remove(int pos, int v) {
        this.Array[pos] = v;
    }
    public void zero(int pos, int v) {
        this.Array[pos] = v;
    }
    public void rand(int pos, int v) {
        this.Array[pos] = v;
    }
    public void fill(int pos, int v) {
        this.Array[pos] = v;
    }
    */
    public void show() {
        int i;
        for (i = 0; i < pos; i++) {
            if(i == 0) {
                System.out.print("[");
            }
            System.out.print(this.Array[i]);
            if(!(i == pos-1)) {
                System.out.print(", ");
            }
            if(i==pos-1) {
                System.out.print("]");
            }
        } 
    }

    public int size() {
        return pos;
    }

    public int value(int p) {
        return Array[p];
    }
}
