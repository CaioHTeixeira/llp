package value;

/**
 *
 * @author usuario
 */
public abstract class ArrayValue extends Value<Array>{
    public ArrayValue(int line){
        super(line);
    }
    public abstract Array value();
}
